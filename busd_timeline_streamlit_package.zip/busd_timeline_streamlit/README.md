# Berkeley and BUSD Educational History Timeline — Streamlit App

An interactive, data-driven timeline tracing how California law, Berkeley housing policy, community organizing, and BUSD reform shaped educational access over time.

## Quick Start

```bash
# 1  Create a virtual environment (recommended)
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate

# 2  Install dependencies
pip install -r requirements.txt

# 3  Run the app
streamlit run app.py
```

The app opens at **http://localhost:8501** by default.

## Project Structure

```
busd_timeline_streamlit/
├── .streamlit/
│   └── config.toml          # Theme colors and server settings
├── app.py                    # Main Streamlit application
├── events.json               # Timeline event data (swap this file to update)
├── requirements.txt          # Python dependencies
└── README.md                 # This file
```

## Data Format

All event data lives in **`events.json`**. The file uses this schema:

```json
{
  "_schema_version": "2.0",
  "events": [
    {
      "id": "unique-id",
      "year": 1865,
      "title": "Event Title",
      "description": "Detailed description of the event.",
      "category": "National",
      "topics": ["Laws", "Policy"],
      "image_url": "https://example.com/image.png",
      "image_caption": "Optional caption for the image.",
      "image_source": "Optional source credit for the image.",
      "source_citation": "Author, Title, Year",
      "source_url": "https://example.com/source"
    }
  ]
}
```

### Field Reference

| Field              | Required | Description                                                    |
| ------------------ | -------- | -------------------------------------------------------------- |
| `id`               | Yes      | Unique identifier (UUID or slug)                               |
| `year`             | Yes      | Integer year the event occurred                                |
| `title`            | Yes      | Short event title                                              |
| `description`      | Yes      | Full narrative description                                     |
| `category`         | Yes      | One of: `California`, `National`, `Berkeley`, `BUSD`           |
| `topics`           | Yes      | List of topic tags, e.g. `["Laws", "Policy"]`                  |
| `image_url`        | No       | URL to an event illustration or photo                          |
| `image_caption`    | No       | Caption text displayed below the image                         |
| `image_source`     | No       | Credit line for the image                                      |
| `source_citation`  | No       | Bibliographic citation for the event narrative                 |
| `source_url`       | No       | Link to the primary source (displayed as a clickable citation) |

### Replacing the Dataset

To update the timeline with new events:

1. Edit or replace `events.json` following the schema above.
2. Restart the Streamlit app (or press **R** in the browser to rerun).
3. New categories and topics are detected automatically — no code changes needed.

## Features

- **Hero / title area** with editorial styling
- **Project context** block explaining the 20-point narrative arc
- **Filterable** by category (California / National / Berkeley / BUSD), topic tags, and year range
- **Summary metrics** showing event counts and time span
- **Scrollable timeline** with year dividers and styled event cards
- **Category badges** and **topic tags** on each event
- **Image support** with optional caption and source credit
- **Source citations** with optional hyperlinks for academic use
- **Responsive** layout for desktop and mobile
- **Accessible** — semantic HTML, readable contrast, keyboard-navigable controls

## Customization

- **Colors / theme**: Edit `.streamlit/config.toml` and the CSS variables at the
  top of `app.py`.
- **Hero text**: Search for `render_hero()` in `app.py`.
- **Context block**: Search for `render_context()` in `app.py`.
- **Metadata notes**: See `busd_timeline_metadata_notes.md` for the aligned 20-point notes and media/source fields.
