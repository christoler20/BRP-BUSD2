# BUSD Timeline Metadata Notes
This document aligns the Streamlit timeline with the 20-point narrative arc and preserves source, media, and archive fields in one place.
## Archive links
- Streamlit app package: pending export
- Timeline dataset (events.json): pending export
- Metadata notes document: pending export

## Timeline points
### 1. California Sanctions Indigenous Unfreedom
- Start Date: 1850/4/22
- End Date: 1850/4/22
- Headline: California Sanctions Indigenous Unfreedom
- Text: Four months before statehood, California passed the Act for the Government and Protection of Indians. The law allowed white settlers to obtain custody of Native children through local justices and enabled forced labor through vagrancy enforcement and other coercive provisions. It matters for this timeline because Berkeley’s schools developed inside a state that paired formal freedom with racialized unfreedom, family separation, and unequal citizenship.
- Media: https://courts.ca.gov/sites/default/files/courts/default/2024-08/module1-resources.pdf
- Media Credit: California Courts. (2024). Early California laws and policies related to California Indians. https://courts.ca.gov/sites/default/files/courts/default/2024-08/module1-resources.pdf
- Media Caption: Reference file summarizing the 1850 Act for the Government and Protection of Indians and its coercive provisions.
- Sources:
  - California Courts. (2024). Early California laws and policies related to California Indians. https://courts.ca.gov/sites/default/files/courts/default/2024-08/module1-resources.pdf

### 2. California Funds White Schooling, Not Black and Chinese Children
- Start Date: 1855/1/1
- End Date: 1855/12/31
- Headline: California Funds White Schooling, Not Black and Chinese Children
- Text: An 1855 state law calculated school funding by counting white children and withheld state support from schools that taught Black and Chinese students. Black Californians still paid taxes into the public system while their children could be excluded from it. This matters because educational inequality in California was built not only through custom, but through public finance.
- Media: https://oag.ca.gov/system/files/media/ch6-ca-reparations.pdf
- Media Credit: California Department of Justice. (2023). Chapter 6: Separate and unequal education. https://oag.ca.gov/system/files/media/ch6-ca-reparations.pdf
- Media Caption: Reference chapter documenting California laws that denied Black children equal access to publicly funded education.
- Sources:
  - California Department of Justice. (2023). Chapter 6: Separate and unequal education. https://oag.ca.gov/system/files/media/ch6-ca-reparations.pdf

### 3. California Builds a Separate-School Regime
- Start Date: 1864/1/1
- End Date: 1866/12/31
- Headline: California Builds a Separate-School Regime
- Text: State law first allowed separate schools for Black children when enough families petitioned for one, then in 1866 let white parents block Black children from white schools by written objection. In places with too few Black students, districts could effectively refuse schooling altogether. These laws made educational access contingent on white approval rather than equal right.
- Media: https://oag.ca.gov/system/files/media/ch6-ca-reparations.pdf
- Media Credit: California Department of Justice. (2023). Chapter 6: Separate and unequal education. https://oag.ca.gov/system/files/media/ch6-ca-reparations.pdf
- Media Caption: Reference chapter tracing the state laws that formalized separate schooling and white-parent veto power.
- Sources:
  - California Department of Justice. (2023). Chapter 6: Separate and unequal education. https://oag.ca.gov/system/files/media/ch6-ca-reparations.pdf

### 4. Ward v. Flood Normalizes Separate Schooling in California
- Start Date: 1874/1/1
- End Date: 1874/12/31
- Headline: Ward v. Flood Normalizes Separate Schooling in California
- Text: In Ward v. Flood, the California Supreme Court upheld segregated schooling while also saying Black children could attend white schools if no separate school existed. The ruling gave California its own version of separate-but-equal before Plessy v. Ferguson. It matters because later fights in Berkeley unfolded against a long state tradition of treating segregation as legally manageable rather than morally intolerable.
- Media: https://oag.ca.gov/system/files/media/ch6-ca-reparations.pdf
- Media Credit: California Department of Justice. (2023). Chapter 6: Separate and unequal education. https://oag.ca.gov/system/files/media/ch6-ca-reparations.pdf
- Media Caption: Reference chapter summarizing Ward v. Flood and California’s separate-school doctrine.
- Sources:
  - California Department of Justice. (2023). Chapter 6: Separate and unequal education. https://oag.ca.gov/system/files/media/ch6-ca-reparations.pdf
  - Burkhardt v. Lofton. (n.d.). Justia. https://law.justia.com/cases/california/court-of-appeal/2d/63/230.html

### 5. Formal School Segregation Ends, Structural Inequality Remains
- Start Date: 1880/1/1
- End Date: 1890/12/31
- Headline: Formal School Segregation Ends, Structural Inequality Remains
- Text: An 1880 California law opened public schools to all children, and in 1890 Wysinger v. Crookshank confirmed that a Black student could attend his local public school under that law. Yet legal access did not undo neighborhood exclusion, unequal resources, or hostile gatekeeping. This turning point matters because the Berkeley story is not simply one of exclusion ending, but of inequality changing form.
- Media: https://oag.ca.gov/system/files/media/ch6-ca-reparations.pdf
- Media Credit: California Department of Justice. (2023). Chapter 6: Separate and unequal education. https://oag.ca.gov/system/files/media/ch6-ca-reparations.pdf
- Media Caption: Reference chapter documenting the legal end of formal school segregation for Black students in California.
- Sources:
  - California Department of Justice. (2023). Chapter 6: Separate and unequal education. https://oag.ca.gov/system/files/media/ch6-ca-reparations.pdf

### 6. Berkeley Creates Single-Family Zoning as a Racial Barrier
- Start Date: 1916/1/1
- End Date: 1916/12/31
- Headline: Berkeley Creates Single-Family Zoning as a Racial Barrier
- Text: Berkeley became the first city in the nation to adopt single-family residential zoning, and later city documents explicitly tie that system to racial exclusion. The policy worked alongside racially restrictive deeds and covenants to keep Black and other nonwhite families out of much of East Berkeley. It matters because school opportunity followed residential lines, so housing exclusion became educational exclusion by another route.
- Media: https://berkeleyca.gov/sites/default/files/2022-02/2021-02-23%20Item%2029%20Resolution%20to%20End%20Exclusionary.pdf
- Media Credit: City of Berkeley. (2021). Resolution to end exclusionary zoning in Berkeley. https://berkeleyca.gov/sites/default/files/2022-02/2021-02-23%20Item%2029%20Resolution%20to%20End%20Exclusionary.pdf
- Media Caption: City resolution summarizing Berkeley’s 1916 single-family zoning system and its role in racial exclusion.
- Sources:
  - City of Berkeley. (2021). Resolution to end exclusionary zoning in Berkeley. https://berkeleyca.gov/sites/default/files/2022-02/2021-02-23%20Item%2029%20Resolution%20to%20End%20Exclusionary.pdf
  - Othering & Belonging Institute. (2019). Roots, race, and place. https://belonging.berkeley.edu/sites/default/files/haasinstitute_rootsraceplace_oct2019_publish.pdf

### 7. Wartime Migration Grows Black Berkeley Under Segregated Housing Conditions
- Start Date: 1942/1/1
- End Date: 1945/12/31
- Headline: Wartime Migration Grows Black Berkeley Under Segregated Housing Conditions
- Text: World War II and its aftermath expanded Berkeley’s Black and working-class population, but housing discrimination sharply limited where many families could live. City and regional histories describe postwar Berkeley as shaped by GI-era benefits, suburban out-migration, and intensifying struggles over fair housing and school segregation. This mattered because where families were allowed to live shaped the schools their children could access and the resources those schools received.
- Media: https://berkeleyca.gov/sites/default/files/documents/2023-09-07_LPC_Item%207_2603-2611%20San%20Pablo_Staff%20Report%20and%20Attachments.pdf
- Media Credit: City of Berkeley. (2023). 2603–2611 San Pablo Avenue staff report and attachments. https://berkeleyca.gov/sites/default/files/documents/2023-09-07_LPC_Item%207_2603-2611%20San%20Pablo_Staff%20Report%20and%20Attachments.pdf
- Media Caption: City historical report describing postwar Berkeley demographics, GI-era changes, and ensuing struggles over fair housing and school segregation.
- Sources:
  - City of Berkeley. (2023). 2603–2611 San Pablo Avenue staff report and attachments. https://berkeleyca.gov/sites/default/files/documents/2023-09-07_LPC_Item%207_2603-2611%20San%20Pablo_Staff%20Report%20and%20Attachments.pdf
  - Othering & Belonging Institute. (2019). Roots, race, and place. https://belonging.berkeley.edu/sites/default/files/haasinstitute_rootsraceplace_oct2019_publish.pdf

### 8. Brown v. Board Redefines the Constitutional Standard
- Start Date: 1954/5/17
- End Date: 1954/5/17
- Headline: Brown v. Board Redefines the Constitutional Standard
- Text: On May 17, 1954, the U.S. Supreme Court ruled that separate educational facilities are inherently unequal. Brown did not automatically desegregate Berkeley, but it changed the legal and moral landscape in which local activists pressed BUSD to act. It matters here because Berkeley’s later reforms were part of a national struggle over what equal education should mean in practice.
- Media: https://www.archives.gov/milestone-documents/brown-v-board-of-education
- Media Credit: National Archives. (2024). Brown v. Board of Education (1954). https://www.archives.gov/milestone-documents/brown-v-board-of-education
- Media Caption: National Archives page for the Brown v. Board decision.
- Sources:
  - National Archives. (2024). Brown v. Board of Education (1954). https://www.archives.gov/milestone-documents/brown-v-board-of-education

### 9. Berkeley NAACP Pushes School Segregation onto the District Agenda
- Start Date: 1957/1/1
- End Date: 1957/12/31
- Headline: Berkeley NAACP Pushes School Segregation onto the District Agenda
- Text: In 1957, Berkeley’s NAACP chapter proposed a citizens’ advisory committee to study segregation in the schools. That intervention helped move school inequality from private grievance to public district business. It matters because formal desegregation in Berkeley began not as administrative generosity, but under organized community pressure.
- Media: https://www.usccr.gov/files/historical/1977/77-033.pdf
- Media Credit: U.S. Commission on Civil Rights. (1977). School desegregation in Berkeley, California. https://www.usccr.gov/files/historical/1977/77-033.pdf
- Media Caption: Federal report recounting Berkeley NAACP advocacy and the district’s desegregation process.
- Sources:
  - U.S. Commission on Civil Rights. (1977). School desegregation in Berkeley, California. https://www.usccr.gov/files/historical/1977/77-033.pdf

### 10. The Alfred Simmons Case Exposes Berkeley Housing Discrimination
- Start Date: 1958/1/1
- End Date: 1958/12/31
- Headline: The Alfred Simmons Case Exposes Berkeley Housing Discrimination
- Text: In 1958, Alfred Simmons, an African American teacher, rented a house in Berkeley’s Elmwood neighborhood and triggered intervention by the police, FBI, and Federal Housing Administration against the white owner. The episode showed that even a Black educator could face punishment through the housing system for crossing racial lines. It matters because residential exclusion helped preserve unequal access to schools long after formal school segregation was under challenge.
- Media: https://belonging.berkeley.edu/sites/default/files/haasinstitute_rootsraceplace_oct2019_publish.pdf
- Media Credit: Othering & Belonging Institute. (2019). Roots, race, and place. https://belonging.berkeley.edu/sites/default/files/haasinstitute_rootsraceplace_oct2019_publish.pdf
- Media Caption: Report summarizing the 1958 Alfred Simmons housing discrimination episode in Berkeley.
- Sources:
  - Othering & Belonging Institute. (2019). Roots, race, and place. https://belonging.berkeley.edu/sites/default/files/haasinstitute_rootsraceplace_oct2019_publish.pdf

### 11. Fair Housing Reform Meets Backlash
- Start Date: 1963/1/1
- End Date: 1967/12/31
- Headline: Fair Housing Reform Meets Backlash
- Text: California passed the Rumford Fair Housing Act in 1963 to bar discrimination in the sale and rental of housing, but voters approved Proposition 14 the next year to protect a landlord’s right to discriminate. In 1967, the U.S. Supreme Court struck Proposition 14 down in Reitman v. Mulkey. This sequence matters because the fight over housing access shaped who could live in Berkeley, build wealth there, and send children to its public schools.
- Media: https://ajud.assembly.ca.gov/sites/ajud.assembly.ca.gov/files/reports/2010%20FEHA%20background%20paper.pdf
- Media Credit: California State Assembly Committee on Judiciary. (2010). Fair employment and housing 50 years after FEHA. https://ajud.assembly.ca.gov/sites/ajud.assembly.ca.gov/files/reports/2010%20FEHA%20background%20paper.pdf
- Media Caption: Background paper tracing the Rumford Act, Proposition 14, and the legal restoration of fair-housing protections.
- Sources:
  - California State Assembly Committee on Judiciary. (2010). Fair employment and housing 50 years after FEHA. https://ajud.assembly.ca.gov/sites/ajud.assembly.ca.gov/files/reports/2010%20FEHA%20background%20paper.pdf
  - Online Archive of California. (n.d.). No on Proposition 14: California Fair Housing Initiative collection. https://oac.cdlib.org/findaid/ark:/13030/kt0b69q1bw/

### 12. Berkeley Desegregates Its Junior High Schools
- Start Date: 1964/1/1
- End Date: 1964/12/31
- Headline: Berkeley Desegregates Its Junior High Schools
- Text: In 1964, Berkeley implemented junior high desegregation after earlier school board votes and organizing battles over the issue. The district redrew attendance patterns so the remaining junior highs would enroll more racially and socioeconomically mixed student bodies. This mattered because Berkeley was testing whether integration would be pursued as district policy rather than left to residential sorting.
- Media: https://www.usccr.gov/files/historical/1977/77-033.pdf
- Media Credit: U.S. Commission on Civil Rights. (1977). School desegregation in Berkeley, California. https://www.usccr.gov/files/historical/1977/77-033.pdf
- Media Caption: Federal report detailing Berkeley’s junior high desegregation plan and implementation.
- Sources:
  - U.S. Commission on Civil Rights. (1977). School desegregation in Berkeley, California. https://www.usccr.gov/files/historical/1977/77-033.pdf

### 13. Berkeley Extends Desegregation to Elementary Schools and Teacher Hiring
- Start Date: 1968/1/1
- End Date: 1968/12/31
- Headline: Berkeley Extends Desegregation to Elementary Schools and Teacher Hiring
- Text: In 1968, Berkeley implemented elementary school desegregation through districtwide busing and zone design, making every child part of the plan at some point in their school career. The district also adopted affirmative-action hiring goals and expanded recruitment of Black teachers while requiring staff training in human relations and multicultural education. It matters because Berkeley linked student assignment, curriculum, and staffing in one of the nation’s most watched local desegregation efforts.
- Media: https://www.usccr.gov/files/historical/1977/77-033.pdf
- Media Credit: U.S. Commission on Civil Rights. (1977). School desegregation in Berkeley, California. https://www.usccr.gov/files/historical/1977/77-033.pdf
- Media Caption: Federal report documenting Berkeley’s elementary desegregation plan, busing structure, and minority teacher recruitment.
- Sources:
  - U.S. Commission on Civil Rights. (1977). School desegregation in Berkeley, California. https://www.usccr.gov/files/historical/1977/77-033.pdf
  - City of Berkeley. (2019). Update on Berkeley’s 2020 Vision. https://berkeleyca.gov/sites/default/files/documents/2019-10-22%20WS%20Item%2001%20Update%20on%20Berkeley%E2%80%99s%202020%20Vision.pdf

### 14. Black Panther Programs in Berkeley Link Education, Health, and Survival
- Start Date: 1968/1/1
- End Date: 1971/12/31
- Headline: Black Panther Programs in Berkeley Link Education, Health, and Survival
- Text: Berkeley sites of the Black Panther Party hosted political education classes, youth programming, and the Free Breakfast for School Children program, while related health work expanded access to care in Black communities. The Berkeley Public Library notes that many participants were Berkeley High and UC Berkeley students as well as community members. This mattered because Black families were not waiting for institutions alone to solve educational inequality; they were building support systems around children themselves.
- Media: https://www.berkeleypubliclibrary.org/black-panther-party-berkeley
- Media Credit: Berkeley Public Library. (2021). The Black Panther Party in Berkeley. https://www.berkeleypubliclibrary.org/black-panther-party-berkeley
- Media Caption: Berkeley Public Library resource describing local Panther breakfast, education, and community programs.
- Sources:
  - Berkeley Public Library. (2021). The Black Panther Party in Berkeley. https://www.berkeleypubliclibrary.org/black-panther-party-berkeley

### 15. Black House Experiments with Black-Centered Schooling
- Start Date: 1970/9/1
- End Date: 1973/6/13
- Headline: Black House Experiments with Black-Centered Schooling
- Text: Black House opened in fall 1970 and entered the Berkeley Experimental Schools Project the next year as an all-Black, Black-staffed educational space designed to connect academic recovery with Black history, pride, and community. Its curriculum paired basic skills with Black philosophy, literature, law, art, and nation-building. It matters because the program showed one local answer to a problem integration alone had not solved: how to make school meaningful and affirming for Black students.
- Media: https://revolution.berkeley.edu/assets/BlackHouse.Extract.BESP_.pdf
- Media Credit: The Berkeley Revolution. (n.d.). Black House extract. https://revolution.berkeley.edu/assets/BlackHouse.Extract.BESP_.pdf
- Media Caption: Historical extract on Black House and its role within Berkeley Experimental Schools Project.
- Sources:
  - The Berkeley Revolution. (n.d.). Black House extract. https://revolution.berkeley.edu/assets/BlackHouse.Extract.BESP_.pdf

### 16. Ashby BART Construction Displaces South Berkeley
- Start Date: 1970/1/1
- End Date: 1979/12/31
- Headline: Ashby BART Construction Displaces South Berkeley
- Text: Construction of the Ashby BART station in the 1970s took property through eminent domain in historically Black South Berkeley. Residents succeeded in preventing elevated tracks from dividing the neighborhood, but the project still caused major disruption and the loss of Black homes and businesses. It matters because school opportunity depends on neighborhood stability, and displacement weakened the community infrastructure around Black families and students.
- Media: https://berkeleyca.gov/sites/default/files/documents/2024-06-25%20Item%2046%20Accepting%20grant%20funding.pdf
- Media Credit: City of Berkeley. (2024). Accepting grant funding. https://berkeleyca.gov/sites/default/files/documents/2024-06-25%20Item%2046%20Accepting%20grant%20funding.pdf
- Media Caption: City report summarizing the impact of Ashby BART construction on South Berkeley’s Black community.
- Sources:
  - City of Berkeley. (2024). Accepting grant funding. https://berkeleyca.gov/sites/default/files/documents/2024-06-25%20Item%2046%20Accepting%20grant%20funding.pdf
  - City of Berkeley. (2024). Equity for Black Berkeley initiative referral. https://berkeleyca.gov/sites/default/files/documents/2024-11-19%20Item%2024%20Referral%20to%20City%20Manager%20%20Equity%20for%20Black%20Berkeley%20(E4BB)%20Initiative.pdf

### 17. School Colors Shows Integration Did Not End Inequality
- Start Date: 1994/1/1
- End Date: 1994/12/31
- Headline: School Colors Shows Integration Did Not End Inequality
- Text: PBS Frontline’s School Colors followed Berkeley High and brought national attention to racial tension and unequal student experience decades after formal desegregation. The 2020 Vision report later cited the film as a major marker in Berkeley’s educational history. It matters because the documentary made visible what simple integration statistics could hide: students could share schools without sharing equal opportunity.
- Media: https://www.pbs.org/wgbh/frontline/documentary/school-colors/
- Media Credit: PBS Frontline. (n.d.). School Colors. https://www.pbs.org/wgbh/frontline/documentary/school-colors/
- Media Caption: Documentary page for School Colors, a 1994 PBS Frontline film on race and education at Berkeley High School.
- Sources:
  - PBS Frontline. (n.d.). School Colors. https://www.pbs.org/wgbh/frontline/documentary/school-colors/
  - City of Berkeley. (2019). Update on Berkeley’s 2020 Vision. https://berkeleyca.gov/sites/default/files/documents/2019-10-22%20WS%20Item%2001%20Update%20on%20Berkeley%E2%80%99s%202020%20Vision.pdf

### 18. Post-School Colors Reform Builds a Community Equity Agenda
- Start Date: 1996/1/1
- End Date: 2002/12/31
- Headline: Post-School Colors Reform Builds a Community Equity Agenda
- Text: From 1996 to 2002, the UC Berkeley Diversity Project studied racial achievement gaps at Berkeley High and recommended reforms, including supports such as the Parent Resource Center and later structural changes. In 2002, United in Action formed to push BUSD toward a total-community approach to racial equity. This period matters because Berkeley moved from documenting disparity to organizing cross-institutional responses to it.
- Media: https://berkeleyca.gov/sites/default/files/documents/2019-10-22%20WS%20Item%2001%20Update%20on%20Berkeley%E2%80%99s%202020%20Vision.pdf
- Media Credit: City of Berkeley. (2019). Update on Berkeley’s 2020 Vision. https://berkeleyca.gov/sites/default/files/documents/2019-10-22%20WS%20Item%2001%20Update%20on%20Berkeley%E2%80%99s%202020%20Vision.pdf
- Media Caption: City report summarizing post-1994 reform efforts, the Diversity Project, and United in Action.
- Sources:
  - City of Berkeley. (2019). Update on Berkeley’s 2020 Vision. https://berkeleyca.gov/sites/default/files/documents/2019-10-22%20WS%20Item%2001%20Update%20on%20Berkeley%E2%80%99s%202020%20Vision.pdf

### 19. Berkeley’s 2020 Vision Institutionalizes Equity Work
- Start Date: 2008/6/24
- End Date: 2019/10/22
- Headline: Berkeley’s 2020 Vision Institutionalizes Equity Work
- Text: Formally established in 2008, Berkeley’s 2020 Vision joined the city, BUSD, UC Berkeley, and Berkeley City College in a long-term campaign to close racial achievement gaps. By 2019, the initiative had become an official framework for tracking outcomes and aligning interventions, including newer BUSD work such as the African American Success Program pilot and targeted literacy and math supports. It matters because Berkeley increasingly treated educational equity as a systemwide responsibility rather than a school-only issue.
- Media: https://berkeleyca.gov/sites/default/files/documents/2019-10-22%20WS%20Item%2001%20Update%20on%20Berkeley%E2%80%99s%202020%20Vision.pdf
- Media Credit: City of Berkeley. (2019). Update on Berkeley’s 2020 Vision. https://berkeleyca.gov/sites/default/files/documents/2019-10-22%20WS%20Item%2001%20Update%20on%20Berkeley%E2%80%99s%202020%20Vision.pdf
- Media Caption: Official city update on Berkeley’s 2020 Vision and its education-equity milestones.
- Sources:
  - City of Berkeley. (2019). Update on Berkeley’s 2020 Vision. https://berkeleyca.gov/sites/default/files/documents/2019-10-22%20WS%20Item%2001%20Update%20on%20Berkeley%E2%80%99s%202020%20Vision.pdf

### 20. BUSD Reparations Recommendations Center Historical Harm and Educational Repair
- Start Date: 2024/6/6
- End Date: 2024/8/14
- Headline: BUSD Reparations Recommendations Center Historical Harm and Educational Repair
- Text: On June 6, 2024, Berkeley Unified’s Reparations Task Force released its final recommendations after more than a year of meetings and community input. Key proposals included a district harm report, curriculum on slavery and its local legacies, and educational payments for eligible students. This matters because Berkeley’s current equity work increasingly ties present disparities to documented historical harm rather than treating them as isolated contemporary outcomes.
- Media: http://www.acgov.org/board/bos_calendar/documents/DocsAgendaReg_8_14_24/GENERAL%20ADMINISTRATION/Regular%20Calendar/Berkeley_USD_reprations_ppt.pdf
- Media Credit: Alameda County. (2024). Berkeley Unified School District reparations presentation. http://www.acgov.org/board/bos_calendar/documents/DocsAgendaReg_8_14_24/GENERAL%20ADMINISTRATION/Regular%20Calendar/Berkeley_USD_reprations_ppt.pdf
- Media Caption: Presentation summarizing the BUSD Reparations Task Force process and recommendations.
- Sources:
  - Alameda County. (2024). Berkeley Unified School District reparations presentation. http://www.acgov.org/board/bos_calendar/documents/DocsAgendaReg_8_14_24/GENERAL%20ADMINISTRATION/Regular%20Calendar/Berkeley_USD_reprations_ppt.pdf

